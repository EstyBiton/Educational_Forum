﻿using AutoMapper;
using Common1.Dto;
using Project.Repositories.Entities;
using Project.Repositories.Interfaces;
using Project.Repositories.Repositories;
using Project.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Services.Services
{
    public class SubjectService : IForumService<SubjectDto>
    {
        private readonly IForumRepository<Subject> subjectRepository;
        private readonly IMapper mapper;

        public SubjectService(IForumRepository<Subject> subjectRepository, IMapper mapper)
        {
            this.subjectRepository = subjectRepository;
            this.mapper = mapper;
        }
        public async Task<SubjectDto> AddAsync(SubjectDto subject)
        {
            await subjectRepository.AddAsync(mapper.Map<Subject>(subject));
            return subject;
        }

        public async Task DeleteByIdAsync(int id)
        {
            await subjectRepository.DeleteByIdAsync(id);
        }


        public async Task<List<SubjectDto>> GetAllAsync()
        {
            var subjects = await subjectRepository.GetAllAsync();
            return mapper.Map<List<SubjectDto>>(subjects);
        }

        public async Task<SubjectDto> GetByIdAsync(int id)
        {
            var subject = await subjectRepository.GetByIdAsync(id);
            return mapper.Map<SubjectDto>(subject);
        }

        public async Task<SubjectDto> UpdateAsync(SubjectDto subject)
        {
            await subjectRepository.UpdateAsync(mapper.Map<Subject>(subject));
            return subject;
        }
    }
}
