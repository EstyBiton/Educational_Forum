﻿using AutoMapper;
using Common1.Dto;
using Project.Repositories.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Services.Interfaces
{
    public interface IForumService<T>
    {
        public Task<T> GetByIdAsync(int id);
        public Task<List<T>> GetAllAsync();
        public Task<T> AddAsync(T item);
        public Task<T> UpdateAsync(T item);
        public Task DeleteByIdAsync(int id);
    }
}
