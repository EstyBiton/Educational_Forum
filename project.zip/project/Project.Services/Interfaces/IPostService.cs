﻿using Common1.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Services.Interfaces
{
    public interface IPostService : IForumService<PostDto>
    {
        Task<List<PostDto>> GetPostsByTopicIdAsync(int topicId);
        Task<int> LikePostAsync(int postId);

    }
}
