﻿using Common1.Dto;
using Microsoft.Extensions.DependencyInjection;
using Project.Repositories;
using Project.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//להתקין את Extensions.DependencyInjection
namespace Project.Services.Services
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddRepository();
            services.AddScoped<IUserService<CounselorDto>, CounselorService>();
            services.AddScoped<IUserService<UserDto>, UserService>();
            services.AddScoped<IForumService<SubjectDto>, SubjectService>();
            services.AddScoped<IForumService<TopicDto>, TopicService>();
            services.AddScoped<IForumService<PostDto>, PostService>();
            services.AddScoped<IPostService, PostService>();
            services.AddScoped<IEmailService, EmailService>();

            services.AddAutoMapper(typeof(MapProfile));
            return services;
        }
    }
}
