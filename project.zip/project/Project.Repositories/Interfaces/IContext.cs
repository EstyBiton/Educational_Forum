﻿using Microsoft.EntityFrameworkCore;
using Project.Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//להתקין את EntityFrameworkCore
//וגם את
//microsoft.extentions.dependencyInjection
namespace Project.Repositories.Repositories
{
    public interface IContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Counselor> Counselors { get; set; }
        public DbSet<Post> Posts { get; set; }
        public DbSet<Topic> Topics { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public Task Save();
    }
}
