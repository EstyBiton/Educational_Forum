﻿using Project.Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Repositories.Interfaces
{
    //האם לעשות אינטרפייס אחד לכולם או אחד לשחקנים ואחד לנושאים ולפוסטים
    public interface IUserRepository<T>
    {
        Task<T> AddAsync(T entity);
        Task DeleteByIdAsync(int id);
        Task<List<T>> GetAllUsersAsync();
        Task<T> GetByIdAsync(int id);
        Task<T> UpdateAsync(T entity);
        Task<bool> EmailExistsAsync(string email); // הוסף את הפונקציה הזו
        Task<bool> UserNameExistsAsync(string userName); // הוסף את הפונקציה הזו

    }

}
