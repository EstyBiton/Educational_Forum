﻿using Microsoft.EntityFrameworkCore;
using Project.Repositories.Entities;
using Project.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Repositories.Repositories
{
    public class SubjectRepository : IForumRepository<Subject>
    {
        public SubjectRepository(IContext context)
        {
            this.context = context;
        }
        private readonly IContext context;
        public async Task<Subject> AddAsync(Subject entity)
        {
            await context.Subjects.AddAsync(entity);
            await context.Save();
            return entity;
        }

        public async Task DeleteByIdAsync(int id)
        {
            var subject = context.Subjects.FirstOrDefault(u => u.Id == id);
            context.Subjects.Remove(subject);
            await context.Save();
        }

        public async Task<List<Subject>> GetAllAsync()
        {
            return await context.Subjects.ToListAsync();
        }

        public async Task<Subject> GetByIdAsync(int id)
        {
            return await context.Subjects.FirstOrDefaultAsync(x => x.Id == id);
        }
        public async Task<Subject> UpdateAsync(Subject entity)
        {
            context.Subjects.Update(entity);
            await context.Save();
            return entity;
        }
    }
}
