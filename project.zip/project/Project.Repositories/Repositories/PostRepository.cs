﻿using Microsoft.EntityFrameworkCore;
using Project.Repositories.Entities;
using Project.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Repositories.Repositories
{
    public class PostRepository : IPostRepository
    {
        private readonly IContext context;
        public PostRepository(IContext context)
        {
            this.context = context;
        }
        //public async Task<Post> AddAsync(Post post)
        //{
        //    await context.Posts.AddAsync(post);
        //    await context.Save();
        //    return post;    
        //}

        public async Task<Post> AddAsync(Post post)
        {
            post.Date = DateTime.Now; // שמור את הזמן המקומי בעת יצירת הפוסט
            await context.Posts.AddAsync(post);
            await context.Save();
            return post;
        }

        public async Task DeleteByIdAsync(int id)
        {
            var post = context.Posts.FirstOrDefault(p => p.Id == id);
            context.Posts.Remove(post);
            await context.Save();
        }

        public async Task<Post> GetByIdAsync(int id)
        {
            return await context.Posts.FirstOrDefaultAsync(x => x.Id == id);
        }
        public async Task<List<Post>> GetAllAsync()
        {
            return await context.Posts.ToListAsync();
        }
        public async Task<Post> UpdateAsync(Post post)
        {
            context.Posts.Update(post);
            await context.Save();
            return post;
        }

        public async Task<List<Post>> GetPostsByTopicIdAsync(int topicId)
        {
            return await context.Posts.Where(post => post.TopicId == topicId).ToListAsync();
        }

    }
}
