﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Repositories.Entities
{
    public class Topic
    {
        public int Id { get; set; }
        public string Title { get; set; }

        //Counselors should know which topics still wait for advice

        [DefaultValue(false)]
        public bool WasAnswered { get; set; }

        //Administrators should lock old topics
        public DateTime DateCreated { get; set; } = DateTime.Now;

        //Topics with the latest activity should be shown first

        //התכונה לא תישמר בבסיס הנתונים אלא תחושב בזמן ריצה
        [NotMapped]
        public DateTime DateLastActive
        {
            get
            {
                return Posts.Any() ? Posts.Max(p => p.Date) : DateCreated;
            }
        }


        //כך משתמשים בזה
        //var topic = context.Topics.Include(t => t.Posts).FirstOrDefault(t => t.Id == topicId);
        //var lastActiveDate = topic?.DateLastActive;

        #region related entities
        //Only user can open a topic
        [ForeignKey("User")]
        public int UserId { get; set; }
        public virtual User User { get; set; }

        public virtual ICollection<Counselor>? Counselors { get; set; }

        public virtual ICollection<Subject>? Subjects { get; set; }

        public virtual ICollection<Post> Posts { get; set; }
        #endregion
    }
}
