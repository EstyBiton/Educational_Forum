﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Repositories.Entities
{
    //התגיות שלנו
    //משמש גם לחיפוש לפי נושאים
    //וגם כי כל יועץ יכול לענות רק לפי תחומי ההתמחות שלנו
    public class Subject
    {
        public int Id { get; set; }

        //כדי שיועץ יוכל לענות גם בתחומים שהם תתי התמחות שלו
        //לדוגמה יועץ שמתמחה באלימות ילדים, יוכל לענות גם בנושא נשיכות
        public int ParentId { get; set; }
        public string Label { get; set; }

        // related entities
        //for "Search topics by subject"
        public virtual ICollection<Topic>? Topics { get; set; }
    }
}
