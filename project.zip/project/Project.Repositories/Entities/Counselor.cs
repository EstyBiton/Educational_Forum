﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Repositories.Entities
{
    public class Counselor
    {
        [Key]
        public int Id { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }

        public string IdentityNumber { get; set; }
        public string PhoneNumber { get; set; }

        #region personal details
        public string Name { get; set; }
        public string Bio { get; set; }
        public int YearsOfExperience { get; set; }
        public string EducationalInstitutions { get; set; }
        public string WorkHistory { get; set; }
        public string AcademicDegrees { get; set; }

        #endregion

        // related entities
        public virtual ICollection<Topic> Topics { get; set; }
        public virtual ICollection<Subject> AreasOfSpecialization { get; set; }
        public virtual ICollection<Post> Posts { get; set; } // Add this line

    }
}
