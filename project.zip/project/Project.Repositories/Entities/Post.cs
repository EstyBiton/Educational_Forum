﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Project.Repositories.Entities
{
    public class Post
    {

        public int Id { get; set; }
        public DateTime Date { get; set; } = DateTime.Now;
        public int Likes { get; set; }
        public string Content { get; set; }

        //אם זה חיובי, אמור לקפוץ מייל למנהל שיחסום את ההודעה
        //אם סתם דיווחו, המשתנה יכול לחזור להיות פולס
        [DefaultValue(false)]
        public bool IsReported { get; set; }

        [DefaultValue(false)]
        public bool IsDeleted { get; set; }

        // related entities

        #region belongs to topic

        [ForeignKey("Topic")]
        public int TopicId { get; set; }
        public virtual Topic Topic { get; set; }

        #endregion

        #region belongs to user/counselor

        //Every post can be made by a user or a counselor
        [ForeignKey("User")]
        public int? UserId { get; set; }
        public virtual User? User { get; set; }

        [ForeignKey("Counselor")]
        public int? CounselorId { get; set; }
        public virtual Counselor? Counselor { get; set; }

        #endregion
    }
}
