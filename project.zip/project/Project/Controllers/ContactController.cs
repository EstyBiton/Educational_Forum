﻿using Common1.Dto;
using Microsoft.AspNetCore.Mvc;
using Project.Services.Interfaces;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        private readonly IEmailService emailService;
        private readonly IUserService<CounselorDto> counselorService;
        private readonly IConfiguration configuration;

        public ContactController(IEmailService emailService, IUserService<CounselorDto> counselorService, IConfiguration configuration)
        {
            this.emailService = emailService;
            this.counselorService = counselorService;
            this.configuration = configuration;
        }

        [HttpPost("counselor")]
        public async Task<IActionResult> ContactCounselor([FromBody] ContactCounselorRequestDto request)
        {
            await emailService.SendContactCounselorEmailAsync(request.CounselorName, request.CounselorEmail, request.UserName, request.UserEmail, request.Message);
            return Ok("Email sent to counselor.");
        }

        [HttpPost("general")]
        public async Task<IActionResult> ContactGeneral([FromBody] ContactRequestDto request)
        {
            string siteManagerEmail = configuration["EmailSettings:SiteManagerEmail"];
            string siteManagerName = configuration["EmailSettings:siteManagerName"];
            await emailService.SendContactEmailAsync(siteManagerName, siteManagerEmail, request.UserName, request.UserEmail, request.Message);
            return Ok("Email sent to general contact.");
        }

    }
}
