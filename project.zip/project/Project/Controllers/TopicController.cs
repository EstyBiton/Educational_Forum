﻿//using Common1.Dto;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using Project.Services.Interfaces;

//// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

//namespace Project.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class TopicController : ControllerBase
//    {
//        private readonly IForumService<TopicDto> service;
//        public TopicController(IForumService<TopicDto> service)
//        {
//            this.service = service;
//        }

//        [HttpGet("{id}")]
//        public async Task<TopicDto> GetById(int id)
//        {
//            return await service.GetByIdAsync(id);
//        }

//        [HttpGet]
//        public async Task<List<TopicDto>> GetAll()
//        {
//            return await service.GetAllAsync();
//        }


//        //[Authorize]
//        //[HttpPost]
//        //public async Task<TopicDto> Post(TopicDto topic)
//        //{
//        //    await service.AddAsync(topic);
//        //    return topic;
//        //}

//        [HttpPost]
//        public async Task<IActionResult> Post([FromForm] TopicDto topic)
//        {
//            try
//            {
//                var addedTopic = await service.AddAsync(topic);
//                if (addedTopic == null)
//                {
//                    return BadRequest(new { message = "Failed to add topic" });
//                }
//                return Ok(addedTopic);
//            }
//            catch (Exception ex)
//            {
//                // החזר שגיאה מסודרת אם התרחש חריג
//                return StatusCode(500, new { message = ex.Message });
//            }
//        }


//        //[Authorize]
//        [HttpPut("{id}")]
//        public async Task<TopicDto> Put(TopicDto topic)
//        {
//            await service.UpdateAsync(topic);
//            return topic;
//        }

//        //[Authorize]
//        [HttpDelete("{id}")]
//        public async Task Delete(int id)
//        {
//            await service.DeleteByIdAsync(id);
//        }


//    }
//}

using Common1.Dto;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Project.Services.Interfaces;
using Project.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TopicController : ControllerBase
    {
        private readonly IForumService<TopicDto> _topicService;
        private readonly IPostService _postService;

        public TopicController(IForumService<TopicDto> topicService, IPostService postService)
        {
            _topicService = topicService;
            _postService = postService;
        }

        [HttpGet("{id}")]
        public async Task<TopicDto> GetById(int id)
        {
            return await _topicService.GetByIdAsync(id);
        }

        [HttpGet]
        public async Task<List<TopicDto>> GetAll()
        {
            return await _topicService.GetAllAsync();
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Post([FromForm] TopicDto topic)
        {
            try
            {
                var addedTopic = await _topicService.AddAsync(topic);
                if (addedTopic == null)
                {
                    return BadRequest(new { message = "Failed to add topic" });
                }
                return Ok(addedTopic);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public async Task<TopicDto> Put(TopicDto topic)
        {
            await _topicService.UpdateAsync(topic);
            return topic;
        }

        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            await _topicService.DeleteByIdAsync(id);
        }

        [HttpGet("{id}/posts")]
        public async Task<ActionResult<IEnumerable<PostDto>>> GetPostsByTopicId(int id)
        {
            try
            {
                var posts = await _postService.GetPostsByTopicIdAsync(id);
                if (posts == null || !posts.Any())
                {
                    return NotFound(new { message = "No posts found for this topic" });
                }
                return Ok(posts);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
    }
}
