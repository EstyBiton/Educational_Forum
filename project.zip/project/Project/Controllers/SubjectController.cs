﻿using Common1.Dto;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Project.Repositories.Entities;
using Project.Services.Interfaces;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubjectController : ControllerBase
    {
        private readonly IForumService<SubjectDto> service;
        public SubjectController(IForumService<SubjectDto> service)
        {
            this.service = service;
        }

        [HttpGet("{id}")]
        public async Task<SubjectDto> GetById(int id)
        {
            return await service.GetByIdAsync(id);
        }

        [HttpGet]
        public async Task<List<SubjectDto>> GetAll()
        {
            return await service.GetAllAsync();
        }

        //[Authorize]
        [HttpPost]
        public async Task<SubjectDto> Post(SubjectDto subject)
        {
            await service.AddAsync(subject);
            return subject;
        }

        //[Authorize]
        [HttpPut("{id}")]
        public async Task<SubjectDto> Put(SubjectDto subject)
        {
            await service.UpdateAsync(subject);
            return subject;
        }

        //[Authorize]
        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            await service.DeleteByIdAsync(id);
        }

        [HttpGet("List")]
        public ActionResult<IEnumerable<Subject>> Get()
        {
            return Ok(SubjectData.Subjects);
        }

    }
}
