﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Common1.Dto;
using Project.Repositories.Entities;
using Project.Services.Interfaces;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using AutoMapper;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogInController : ControllerBase
    {
        private readonly IUserService<UserDto> UserService;
        private readonly IUserService<CounselorDto> CounselorService;

        private readonly IConfiguration config;
        public LogInController(IUserService<UserDto> UserService, IUserService<CounselorDto> CounselorService, IConfiguration config)
        {
            this.UserService = UserService;
            this.CounselorService = CounselorService;
            this.config = config;
        }

        ///זה לא בטיחותי שזה נשלח כך! זה צריך להישלח בגוף

        //מועתק מחייקי
        //[HttpPost("LogIn")]
        [HttpPost("SignIn")]

        public IActionResult Post([FromBody] LoginRequestDto loginModel)
        {
            //אימות משתמש 
            var user = Authenticate(loginModel.Name, loginModel.Password);
            if (user != null)
            {
                //יוצרת טוקן
                var token = Generate(user);
                return Ok(token);
            }
            return null;
        }

        //כשזה היה ציבורי, הפונקציה לא עבדה והסווגר לא יכל לעלות. מעניין למה
        private string Generate(object user)
        {
            UserDto userDto = new UserDto();
            CounselorDto counselorDto = new CounselorDto();
            string type = "";

            if (user is UserDto)
            {
                userDto = (UserDto)user;
                type = "user";
            }
            else
                if (user is CounselorDto)
            {
                counselorDto = (CounselorDto)user;
                type = "counselor";
            }

            //מפתח להצפנה
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]));
            var creds = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            //אלגוריתם להצפנה
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new Claim[] { };
            if (type == "user")
            {
                claims = new[]
                {
                        new Claim("id", userDto.Id.ToString()),
                        new Claim(ClaimTypes.Name,userDto.Name),
                        new Claim(ClaimTypes.Email, userDto.Email),
                        new Claim(ClaimTypes.Role, type)
                        // Add other claims as needed based on user properties
                    };
            }
            else
            {
                claims = new[]
                  {

                        new Claim("id", counselorDto.Id.ToString()),
                        new Claim(ClaimTypes.Name, counselorDto.Name),
                        new Claim(ClaimTypes.Email, counselorDto.Email),
                        new Claim(ClaimTypes.Role,type),
                        // Add other claims as needed based on user properties
                    };
            }

            var token = new JwtSecurityToken(config["Jwt:Issuer"], config["Jwt:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(15),
                signingCredentials: credentials);
            return new JwtSecurityTokenHandler().WriteToken(token);
        }


        private object Authenticate(string name, string password)
        {
            // Check if the user is a counselor
            Task<List<CounselorDto>> lst = CounselorService.GetAllAsync();

            var counselor = lst.Result.FirstOrDefault(x => x.Name == name
                 && x.Password == password);
            if (counselor != null)
            {
                // If a counselor is found, return the counselor
                return counselor;
            }

            // If not a counselor, check if it's a regular user
            var user = UserService.GetAllAsync().Result.FirstOrDefault(x => x.Name.ToLower() == name.ToLower()
            && x.Password == password);
            if (user != null)
            {
                // If a user is found, return the user
                return user;
            }

            // If neither counselor nor user found, return null
            return null;
        }

    }

}


