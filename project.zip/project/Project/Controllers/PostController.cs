﻿//using Common1.Dto;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using MimeKit;
//using Project.Services.Interfaces;
//using Project.Services.Services;

//// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

//namespace Project.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class PostController : ControllerBase
//    {
//        private readonly IPostService service;
//        private readonly IConfiguration configuration;
//        private readonly IEmailService emailService;


//        public PostController(IPostService service, IEmailService emailService, IConfiguration configuration)
//        {
//            this.service = service;
//            this.emailService = emailService;
//            this.configuration = configuration;
//        }

//        [HttpGet("{id}")]
//        //[Authorize]
//        public async Task<PostDto> GetById(int id)
//        {
//            return await service.GetByIdAsync(id);
//        }

//        [HttpPost("send-report-email/{postId}")]
//        public async Task<IActionResult> SendReportEmail(int postId)
//        {
//            PostDto post = await service.GetByIdAsync(postId);
//            if (post == null)
//            {
//                return NotFound("Post not found");
//            }
//            string siteManagerEmail = configuration["EmailSettings:SiteManagerEmail"];
//            string siteManagerName = configuration["EmailSettings:siteManagerName"];

//            // יצירת טוקן ייחודי ושמירתו במסד הנתונים

//            var token = Guid.NewGuid().ToString();
//            var deleteToken = new DeleteToken
//            {
//                PostId = postId,
//                Token = token,
//                Expiration = DateTime.UtcNow.AddHours(1) // תקופת תוקף הטוקן, לדוגמה שעה
//            };
//            context.DeleteTokens.Add(deleteToken);
//            await context.SaveChangesAsync();


//            // בניית קישור למחיקה
//            string deleteLink = $"http://localhost:3000/delete-post/{postId}";
//            await emailService.SendReportEmailAsync(siteManagerName, siteManagerEmail, post.Content, deleteLink);
//            return Ok("Email sent");
//        }


//        [HttpGet]
//        public async Task<List<PostDto>> GetAll()
//        {
//            return await service.GetAllAsync();
//        }

//        ////לא מחזיר שום ערך כתגובה 
//        //[Authorize]
//        //[HttpPost]
//        //public async Task Post(PostDto post)
//        //{

//        //    await service.AddAsync(post);

//        //}

//        //הקודם לא החזיר שום ערך, ולנו כן היה חשוב לקבל את הפוסט שעודכן במערכת
//        [HttpPost]
//        public async Task<ActionResult<PostDto>> Post(PostDto post)
//        {
//            var addedPost = await service.AddAsync(post);
//            if (addedPost == null)
//            {
//                return BadRequest("Failed to add post");
//            }

//            //מחזיר את הפוסט שהתווסף ועוד
//            return Ok(addedPost); // או CreatedAtAction או טיפול אחר בהתאם לדרישות האפליקציה שלך
//        }




//        //[Authorize]
//        [HttpPut("{id}")]
//        public async Task Put(PostDto post)
//        {
//            await service.UpdateAsync(post);
//        }


//        //[Authorize]
//        [HttpDelete("{id}")]
//        public async Task Delete(int id)
//        {
//            await service.DeleteByIdAsync(id);
//        }

//        [HttpPost("like/{id}")]
//        public async Task<IActionResult> LikePost(int id)
//        {
//            try
//            {
//                var likesCount = await service.LikePostAsync(id);
//                return Ok(likesCount);
//            }
//            catch (ArgumentException ex)
//            {
//                return NotFound(ex.Message);
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Internal server error: {ex.Message}");
//            }
//        }

//    }
//}


using Common1.Dto;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Project.DataContext;
using Project.Repositories.Entities;
using Project.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostController : ControllerBase
    {
        private readonly IPostService service;
        private readonly IEmailService emailService;
        private readonly IConfiguration configuration;
        private readonly ApplicaionDbContext context;

        public PostController(IPostService service, IEmailService emailService, IConfiguration configuration, ApplicaionDbContext context)
        {
            this.service = service;
            this.emailService = emailService;
            this.configuration = configuration;
            this.context = context;
        }

        [HttpGet("{id}")]
        public async Task<PostDto> GetById(int id)
        {
            return await service.GetByIdAsync(id);
        }

        [HttpPost("send-report-email/{postId}")]
        public async Task<IActionResult> SendReportEmail(int postId)
        {
            PostDto post = await service.GetByIdAsync(postId);
            if (post == null)
            {
                return NotFound("Post not found");
            }

            string siteManagerEmail = configuration["EmailSettings:SiteManagerEmail"];
            string siteManagerName = configuration["EmailSettings:SiteManagerName"];

            // יצירת טוקן ייחודי ושמירתו במסד הנתונים
            var token = Guid.NewGuid().ToString();
            var deleteToken = new DeleteToken
            {
                PostId = postId,
                Token = token,
                Expiration = DateTime.UtcNow.AddHours(48) // תקופת תוקף הטוקן, לדוגמה שעה
            };
            context.DeleteTokens.Add(deleteToken);
            await context.SaveChangesAsync();

            // בניית קישור למחיקה
            string deleteLink = $"http://localhost:3000/delete-post/{token}";
            await emailService.SendReportEmailAsync(siteManagerName, siteManagerEmail, post.Content, deleteLink);
            return Ok("Email sent");
        }

        [HttpGet("delete-post/{token}")]
        public async Task<IActionResult> GetPostByToken(string token)
        {
            var deleteToken = await context.DeleteTokens.FirstOrDefaultAsync(t => t.Token == token);
            if (deleteToken == null || deleteToken.Expiration < DateTime.UtcNow)
            {
                return NotFound("Token not found or expired");
            }

            var post = await context.Posts.FirstOrDefaultAsync(p => p.Id == deleteToken.PostId);
            if (post == null)
            {
                return NotFound("Post not found");
            }

            return Ok(new { post.Content });
        }

        [HttpGet]
        public async Task<List<PostDto>> GetAll()
        {
            return await service.GetAllAsync();
        }

        [HttpPost]
        public async Task<ActionResult<PostDto>> Post(PostDto post)
        {
            var addedPost = await service.AddAsync(post);
            if (addedPost == null)
            {
                return BadRequest("Failed to add post");
            }
            return Ok(addedPost);
        }

        [HttpPut("{id}")]
        public async Task Put(PostDto post)
        {
            await service.UpdateAsync(post);
        }

        //[HttpDelete("{id}")]
        //public async Task Delete(int id)
        //{
        //    await service.DeleteByIdAsync(id);
        //}

        //[HttpDelete("delete-post/{postId}")]
        //public async Task<IActionResult> DeletePost(int postId, string token)
        //{
        //    // חיפוש הטוקן במסד הנתונים
        //    var deleteToken = await context.DeleteTokens.FirstOrDefaultAsync(dt => dt.PostId == postId && dt.Token == token);

        //    if (deleteToken == null || deleteToken.Expiration < DateTime.UtcNow)
        //    {
        //        return BadRequest("Invalid or expired token");
        //    }

        //    // מחיקת ההודעה
        //    var post = await context.Posts.FindAsync(postId);
        //    if (post == null)
        //    {
        //        return NotFound();
        //    }

        //    context.Posts.Remove(post);
        //    await context.SaveChangesAsync();

        //    // מחיקת הטוקן לאחר השימוש
        //    context.DeleteTokens.Remove(deleteToken);
        //    await context.SaveChangesAsync();

        //    return Ok("Post deleted successfully");
        //}


        //[HttpDelete("delete-post/{postId}")]
        //public async Task<IActionResult> DeletePost(int postId, [FromQuery] string token)
        //{
        //    if (string.IsNullOrEmpty(token))
        //    {
        //        return BadRequest("Token is missing");
        //    }

        //    // חיפוש הטוקן במסד הנתונים
        //    var deleteToken = await context.DeleteTokens.FirstOrDefaultAsync(dt => dt.PostId == postId && dt.Token == token);

        //    if (deleteToken == null || deleteToken.Expiration < DateTime.UtcNow)
        //    {
        //        return BadRequest("Invalid or expired token");
        //    }

        //    // מחיקת ההודעה
        //    var post = await context.Posts.FindAsync(postId);
        //    if (post == null)
        //    {
        //        return NotFound();
        //    }

        //    context.Posts.Remove(post);
        //    await context.SaveChangesAsync();

        //    // מחיקת הטוקן לאחר השימוש
        //    context.DeleteTokens.Remove(deleteToken);
        //    await context.SaveChangesAsync();

        //    return Ok("Post deleted successfully");
        //}

        //[HttpDelete("delete-post/{token}")]
        //public async Task<IActionResult> DeletePost(string token)
        //{
        //    if (string.IsNullOrEmpty(token))
        //    {
        //        return BadRequest("Token is missing");
        //    }

        //    // חיפוש הטוקן במסד הנתונים
        //    var deleteToken = await context.DeleteTokens.FirstOrDefaultAsync(dt => dt.Token == token);

        //    if (deleteToken == null || deleteToken.Expiration < DateTime.UtcNow)
        //    {
        //        return BadRequest("Invalid or expired token");
        //    }

        //    // מחיקת ההודעה
        //    var post = await context.Posts.FindAsync(deleteToken.PostId);
        //    if (post == null)
        //    {
        //        return NotFound();
        //    }

        //    context.Posts.Remove(post);
        //    await context.SaveChangesAsync();

        //    // מחיקת הטוקן לאחר השימוש
        //    context.DeleteTokens.Remove(deleteToken);
        //    await context.SaveChangesAsync();

        //    return Ok("Post deleted successfully");
        //}


        [HttpDelete("delete-post/{token}")]
        public async Task<IActionResult> DeletePost(string token)
        {
            if (string.IsNullOrEmpty(token))
            {
                return BadRequest("Token is missing");
            }

            //חיפוש הטוקן במסד הנתונים
            var deleteToken = await context.DeleteTokens.FirstOrDefaultAsync(dt => dt.Token == token);

            if (deleteToken == null || deleteToken.Expiration < DateTime.UtcNow)
            {
                return BadRequest("Invalid or expired token");
            }

            //מחיקת ההודעה
            var post = await context.Posts.FindAsync(deleteToken.PostId);
            if (post == null)
            {
                return NotFound();
            }

            context.Posts.Remove(post);
            await context.SaveChangesAsync();

            //מחיקת הטוקן לאחר השימוש
            context.DeleteTokens.Remove(deleteToken);
            await context.SaveChangesAsync();

            return Ok("Post deleted successfully");
        }


        [HttpPost("like/{id}")]
        public async Task<IActionResult> LikePost(int id)
        {
            try
            {
                var likesCount = await service.LikePostAsync(id);
                return Ok(likesCount);
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}