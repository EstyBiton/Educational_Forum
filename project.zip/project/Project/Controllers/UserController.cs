﻿using AutoMapper;
using Common1.Dto;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Project.Repositories.Interfaces;
using Project.Services.Interfaces;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Project.Controllers
{
    //כל הפונקציות רק למאומתים חוץ מיצירת משתמש חדש
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService<UserDto> service;
        private readonly IUserService<CounselorDto> counselorService;

        public UserController(IUserService<UserDto> service, IUserService<CounselorDto> counselorService)
        {
            this.service = service;
            this.counselorService = counselorService;
        }

        //[Authorize]
        [HttpGet("{id}")]
        public async Task<UserDto> Get(int id)
        {
            //var user = await userRepository.GetByIdAsync(id);
            //return mapper.Map<UserDto>(user);

            return await service.GetByIdAsync(id);
        }

        //לא בטוח שצריך את זה במשתמשים, אבל זה מופיע בממשק
        //[Authorize]
        [HttpGet]
        public async Task<List<UserDto>> GetAll()
        {
            return await service.GetAllAsync();
        }

        //[HttpPost]

        //public async Task<UserDto> Post(UserDto user)
        //{
        //    await service.AddAsync(user);
        //    return user;
        //}

        //אתי
        //[HttpPost("SignUp")]
        //public async Task<int?> SignUp([FromForm] UserDto entity)
        //{
        //    return (await service.AddAsync(entity))?.Id;
        //}

        //גיפיטי, כדי שההרשמה תבדוק אם האימייל קיים או לא
        //[HttpPost("SignUp")]
        //public async Task<IActionResult> SignUp([FromForm] UserDto entity)
        //{
        //    if (await service.EmailExists(entity.Email))
        //    {
        //        return Conflict(new { message = "Email already exists" });
        //    }

        //    if (await service.UserNameExists(entity.Name))
        //    {
        //        return Conflict(new { message = "Username already exists" });
        //    }

        //    var newUser = await service.AddAsync(entity);
        //    if (newUser == null)
        //    {
        //        return StatusCode(500, "A problem happened while handling your request.");
        //    }

        //    return Ok(newUser.Id);
        //}

        [HttpPost("SignUp")]
        public async Task<IActionResult> SignUp([FromForm] UserDto entity)
        {
            // בדיקת אימייל ושם משתמש בשירותי service ו-counselorService בנפרד
            bool emailExistsService = await service.EmailExists(entity.Email);
            bool emailExistsCounselorService = await counselorService.EmailExists(entity.Email);
            bool userNameExistsService = await service.UserNameExists(entity.Name);
            bool userNameExistsCounselorService = await counselorService.UserNameExists(entity.Name);

            // בדיקה אם האימייל או השם קיימים באחד מהשירותים
            bool emailExists = emailExistsService || emailExistsCounselorService;
            bool userNameExists = userNameExistsService || userNameExistsCounselorService;

            if (emailExists || userNameExists)
            {
                // בדיקה האם האימייל והשם כבר קיימים יחד
                if (emailExists && userNameExists)
                {
                    return Conflict(new { message = "Email and Username already exist" });
                }
                else if (emailExists)
                {
                    return Conflict(new { message = "Email already exists" });
                }
                else if (userNameExists)
                {
                    return Conflict(new { message = "Username already exists" });
                }
            }
            else
            {
                var newUser = await service.AddAsync(entity);
                if (newUser == null)
                {
                    return StatusCode(500, "A problem happened while handling your request.");
                }

                return Ok(newUser.Id);
            }

            return StatusCode(500, "A problem happened while handling your request.");
        }

        //גרסה משודרגת של צ'אט גיפיטי
        //בדיקה רק כשבדק ביוזר
        //[HttpPost("SignUp")]
        //public async Task<IActionResult> SignUp([FromForm] UserDto entity)
        //{
        //    bool emailExists = await service.EmailExists(entity.Email) && await counselorService.EmailExists(entity.Email);
        //    bool userNameExists = await service.UserNameExists(entity.Name) && await counselorService.UserNameExists(entity.Name);

        //    if (emailExists || userNameExists)
        //    {
        //        // בדיקה האם האימייל והשם כבר קיימים יחד
        //        if (emailExists && userNameExists)
        //        {
        //            return Conflict(new { message = "Email and Username already exist" });
        //        }
        //        else if (emailExists)
        //        {
        //            return Conflict(new { message = "Email already exists" });
        //        }
        //        else if (userNameExists)
        //        {
        //            return Conflict(new { message = "Username already exists" });
        //        }
        //    }
        //    else
        //    {
        //        var newUser = await service.AddAsync(entity);
        //        if (newUser == null)
        //        {
        //            return StatusCode(500, "A problem happened while handling your request.");
        //        }

        //        return Ok(newUser.Id);
        //    }

        //    return StatusCode(500, "A problem happened while handling your request.");
        //}




        //[Authorize]
        [HttpPut("{id}")]
        public async Task<UserDto> Put(UserDto user)
        {
            await service.UpdateAsync(user);
            return user;
        }

        //[Authorize]
        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            await service.DeleteByIdAsync(id);
        }
    }
}

