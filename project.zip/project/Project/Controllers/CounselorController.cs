﻿using Common1.Dto;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Project.Services.Interfaces;
using Project.Services.Services;


namespace Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CounselorController : ControllerBase
    {
        private readonly IUserService<CounselorDto> service;
        private readonly IUserService<UserDto> userService;

        public CounselorController(IUserService<CounselorDto> service, IUserService<UserDto> userService)
        {
            this.service = service;
            this.userService = userService;
        }

        [HttpGet("{id}")]
        public async Task<CounselorDto> GetById(int id)
        {
            return await service.GetByIdAsync(id);
        }

        [HttpGet]
        public async Task<List<CounselorDto>> GetAll()
        {
            return await service.GetAllAsync();
        }

        [HttpPost("SignUp")]
        public async Task<IActionResult> SignUp([FromForm] CounselorDto entity)
        {
            bool emailExistsService = await service.EmailExists(entity.Email);
            bool emailExistsUserService = await userService.EmailExists(entity.Email);
            bool userNameExistsService = await service.UserNameExists(entity.Name);
            bool userNameExistsUserService = await userService.UserNameExists(entity.Name);

            bool emailExists = emailExistsService || emailExistsUserService;
            bool userNameExists = userNameExistsService || userNameExistsUserService;

            if (emailExists || userNameExists)
            {
                // בדיקה האם האימייל והשם כבר קיימים יחד
                if (emailExists && userNameExists)
                {
                    return Conflict(new { message = "Email and Username already exist" });
                }
                else if (emailExists)
                {
                    return Conflict(new { message = "Email already exists" });
                }
                else if (userNameExists)
                {
                    return Conflict(new { message = "Username already exists" });
                }
            }
            else
            {
                var newUser = await service.AddAsync(entity);
                if (newUser == null)
                {
                    return StatusCode(500, "A problem happened while handling your request.");
                }
                if (newUser.Id == 0)
                {
                    return StatusCode(500, "Failed to retrieve the ID for the new counselor.");
                }


                return Ok(newUser.Id);
            }

            return StatusCode(500, "A problem happened while handling your request.");
        }


        //[Authorize]
        [HttpPut("{id}")]
        public async Task<CounselorDto> Put(CounselorDto counselor)
        {
            await service.UpdateAsync(counselor);
            return counselor;
        }


        //[Authorize]
        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            await service.DeleteByIdAsync(id);
        }
    }
}
