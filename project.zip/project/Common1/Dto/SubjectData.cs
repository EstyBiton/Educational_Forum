﻿using Project.Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common1.Dto
{
    public static class SubjectData
    {
        public static List<Subject> Subjects => new List<Subject>
    {
        new Subject { Id = 1, Label = "בעיות התנהגות" },
        new Subject { Id = 2, Label = "התקפי זעם", ParentId = 1 },
        new Subject { Id = 3, Label = "תוקפנות", ParentId = 1 },
        new Subject { Id = 4, Label = "שקרים", ParentId = 1 },
        new Subject { Id = 5, Label = "גניבה", ParentId = 1 },
        new Subject { Id = 6, Label = "קשיי למידה" },
        new Subject { Id = 7, Label = "דיסלקציה", ParentId = 6 },
        new Subject { Id = 8, Label = "דיסגרפיה", ParentId = 6 },
        new Subject { Id = 9, Label = "דיסקלקוליה", ParentId = 6 },
        new Subject { Id = 10, Label = "קשיי ריכוז", ParentId = 6 },
        new Subject { Id = 11, Label = "יחסים חברתיים" },
        new Subject { Id = 12, Label = "חברות", ParentId = 11 },
        new Subject { Id = 13, Label = "חרם חברתי", ParentId = 11 },
        new Subject { Id = 14, Label = "קונפליקטים חברתיים", ParentId = 11 },
        new Subject { Id = 15, Label = "ביישנות", ParentId = 11 },
        new Subject { Id = 16, Label = "התפתחות רגשית" },
        new Subject { Id = 17, Label = "ויסות רגשי", ParentId = 16 },
        new Subject { Id = 18, Label = "כעס ותסכול", ParentId = 16 },
        new Subject { Id = 19, Label = "שמחה והתרגשות", ParentId = 16 },
        new Subject { Id = 20, Label = "חרדות ופחדים", ParentId = 16 },
        new Subject { Id = 21, Label = "תקשורת עם ילדים" },
        new Subject { Id = 22, Label = "הקשבה ואמפתיה", ParentId = 21 },
        new Subject { Id = 23, Label = "שיתוף פעולה", ParentId = 21 },
        new Subject { Id = 24, Label = "כישורי שיחה", ParentId = 21 },
        new Subject { Id = 25, Label = "סדר יום והרגלים" },
        new Subject { Id = 26, Label = "זמן שינה", ParentId = 25 },
        new Subject { Id = 27, Label = "זמן ארוחה", ParentId = 25 },
        new Subject { Id = 28, Label = "משחק ופנאי", ParentId = 25 },
        new Subject { Id = 29, Label = "התמודדות עם קשיים" },
        new Subject { Id = 30, Label = "כישורי התמודדות", ParentId = 29 },
        new Subject { Id = 31, Label = "תמיכה רגשית", ParentId = 29 },
        new Subject { Id = 32, Label = "עזרה מקצועית", ParentId = 29 },
        new Subject { Id = 33, Label = "בריאות והתפתחות" },
        new Subject { Id = 34, Label = "תזונה ובריאות", ParentId = 33 },
        new Subject { Id = 35, Label = "פעילות גופנית", ParentId = 33 },
        new Subject { Id = 36, Label = "מעקב רפואי", ParentId = 33 },
        new Subject { Id = 37, Label = "סביבה חינוכית" },
        new Subject { Id = 38, Label = "בית ספר", ParentId = 37 },
        new Subject { Id = 39, Label = "גן ילדים", ParentId = 37 },
        new Subject { Id = 40, Label = "חינוך ביתי", ParentId = 37 },
        new Subject { Id = 41, Label = "תחומי עניין ופנאי" },
        new Subject { Id = 42, Label = "תחביבים ותחומי עניין", ParentId = 41 },
        new Subject { Id = 43, Label = "פעילויות חוץ", ParentId = 41 },
        new Subject { Id = 44, Label = "משחקי מחשב ווידאו", ParentId = 41 },
        new Subject { Id = 45, Label = "קריאה וספרים", ParentId = 41 },
    };
    }

}
