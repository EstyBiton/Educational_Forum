﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common1.Dto
{
    public class ContactCounselorRequestDto : ContactRequestDto
    {
        public string CounselorName { get; set; }
        public string CounselorEmail { get; set; }
    }

}
