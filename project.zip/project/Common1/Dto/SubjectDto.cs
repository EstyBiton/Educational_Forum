﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common1.Dto
{
    public class SubjectDto
    {
        public int Id { get; set; }
        public int ParentId { get; set; }
        public string Label { get; set; }

        // IDs of related entities
        public List<int> TopicIds { get; set; }

    }
}
