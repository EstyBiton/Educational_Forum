﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Common1.Dto
{
    public class CounselorDto
    {
        public int Id { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }

        public string IdentityNumber { get; set; }
        public string PhoneNumber { get; set; }

        #region personal details
        public string Name { get; set; }
        public string Bio { get; set; }
        public int YearsOfExperience { get; set; }
        public string EducationalInstitutions { get; set; }
        public string WorkHistory { get; set; }
        public string AcademicDegrees { get; set; }

        #endregion
        // IDs of related entities
        //   public List<int> AnsweredTopicsIds { get; set; }
        //  public List<int> AreasOfSpecializationIds { get; set; }
    }
}
