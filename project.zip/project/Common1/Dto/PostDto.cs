﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common1.Dto
{
    public class PostDto
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public int Likes { get; set; }
        public string Content { get; set; }
        public bool IsReported { get; set; }
        public bool IsDeleted { get; set; }

        // IDs of related entities
        public int TopicId { get; set; }

        //Only one of them should be full
        public int? UserId { get; set; }
        public int? CounselorId { get; set; }

    }
}
